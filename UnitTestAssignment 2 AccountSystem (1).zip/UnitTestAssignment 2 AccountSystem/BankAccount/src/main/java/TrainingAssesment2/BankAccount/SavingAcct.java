package TrainingAssesment2.BankAccount;

public class SavingAcct extends BankAccounts{

		public SavingAcct(int AcctNo, double Bal) {
			super(AcctNo, Bal);
			
		}
		public SavingAcct(int AcctNo) {
			super(AcctNo);
			
		}
		
		@Override
		public void OpenAccount() {
			// TODO Auto-generated method stub
			
		}
}
