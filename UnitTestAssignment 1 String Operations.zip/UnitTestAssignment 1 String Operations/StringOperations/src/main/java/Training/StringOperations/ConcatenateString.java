package Training.StringOperations;

public class ConcatenateString {
	
	public String Concatenate(String Str1 ,String Str2)
	{
		String Result =Str1 +" "+ Str2;
		return Result;
	}

}
