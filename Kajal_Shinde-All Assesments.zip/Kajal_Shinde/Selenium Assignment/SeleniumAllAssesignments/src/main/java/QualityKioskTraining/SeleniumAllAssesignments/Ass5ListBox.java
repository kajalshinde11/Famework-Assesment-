package QualityKioskTraining.SeleniumAllAssesignments;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Ass5ListBox 
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver" ,"D:\\Drivers\\ChromeDriver.exe");
		ChromeDriver D = new ChromeDriver();
		D.get("https://letskodeit.teachable.com/p/practice");
		
		D.manage().window().maximize();
		
		WebElement SelFruitsCombo=D.findElementById("multiple-select-example");
		Select Se1=new Select(SelFruitsCombo);
		
		Se1.selectByValue("orange");
		
		List<String>FruitNames=new ArrayList<String>();
		FruitNames.add("Apple");
		FruitNames.add("Orange");
		FruitNames.add("Peach");
		
	List<WebElement>AllFruitOptions=Se1.getOptions();
		
		for(WebElement Optn:AllFruitOptions)
	{
            String OptionText=Optn.getText();
			if(FruitNames.contains(OptionText))
			{
				System.out.println("CORRECT OPTIONS ARE PRESENT .....PASSED");
			}
			else
			{
				
				System.out.println("INCORRECT OPTIONS "+OptionText+"IS FOUND ...FAILED");
			}
	}

	}
}



