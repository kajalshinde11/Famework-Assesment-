package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ass4DisableButton 
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get(" https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		D.manage().window().maximize();
	
		
		D.switchTo().frame("iframeResult");
		WebElement ClickmeBtn=D.findElementByXPath("//button[text()='Click Me!']");
		boolean ClickmeBtnIsDisplayed=ClickmeBtn.isEnabled();
		if(ClickmeBtnIsDisplayed==false)
		{
			System.out.println("Click button By You is DISABLED ");
		}
		else
		{
			System.out.println("Click button By You is NOT DISABLED ");
		}
		D.close();
	}

}
