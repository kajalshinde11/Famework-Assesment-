package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ass7RetriveCompanyNameAndPrint 
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://www.w3schools.com/html/tryit.asp?filename=tryhtml_table_intro");
		D.manage().window().maximize();
		
		D.switchTo().frame("iframeResult");
		WebElement companyName = D.findElementByXPath("//table//td[text()='UK']/preceding-sibling::td[last()]");
		System.out.print("Company Name from country UK : ");
		System.out.println(companyName.getText());
		D.quit();

		

	}

}
