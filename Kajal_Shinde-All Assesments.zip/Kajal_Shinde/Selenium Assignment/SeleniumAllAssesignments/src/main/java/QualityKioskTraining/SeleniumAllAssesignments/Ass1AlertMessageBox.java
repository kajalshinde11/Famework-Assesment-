package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ass1AlertMessageBox
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://letskodeit.teachable.com/p/practice");
		D.manage().window().maximize();
		
		WebElement EnterNameText=D.findElementById("name");
		EnterNameText.sendKeys("Kajal");
		WebElement ConfirmButton=D.findElementById("confirm btn");
		ConfirmButton.click();
		
		String alertTxt=D.switchTo().alert().getText();
		if(alertTxt.contains("Kajal"));
		D.switchTo().alert().dismiss();

	}

}
