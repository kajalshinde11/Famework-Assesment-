package SeleniumScript.OKTraining;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathClassAssignment {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		
		D.manage().window().maximize();
		D.get("https://www.w3schools.com/Css/tryit.asp?filename=trycss_table_padding");
		D.switchTo().frame("iframeResult");
		
        WebElement Table=D.findElementByXPath("//table/descendant::td[text()='Swanson']/following-sibling::td");
        
        System.out.println(Table.getText());
	}

}
