package SeleniumScript.OKTraining;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassAssignmentCheckBoxesChekNChekitsChecked {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
	    ChromeDriver D =new ChromeDriver();
		D.get("https://letskodeit.teachable.com/p/practice");
		
		/*WebElement BnzCheck=D.findElementById("benzcheck");
		WebElement BmwCheck=D.findElementById("bmwcheck");
		WebElement HondaCheck=D.findElementById("hondacheck");
		
		if(BnzCheck.isSelected()==true && BmwCheck.isSelected()==true && HondaCheck.isSelected()==true)
			System.out.println("All the checked.......PASSED");
		else
			System.out.println("All the checked.......FAILD");*/
		
		//Solution 2 :
		 List<WebElement>Checkboxes=D.findElementsByCssSelector("input[type='checkbox']");
			
		  System.out.println(Checkboxes.size());
		  
		//Solution 3 :
		  boolean FoundSelected=true;
		  int i=0;
		  while(i<Checkboxes.size())
		  {
			WebElement chek=Checkboxes.get(i);
			chek.click();
			boolean IsCheckBoxSelected=chek.isSelected();
			if(IsCheckBoxSelected==true)
			
				FoundSelected=true;
				i++;
			
			if(FoundSelected==false)
				System.out.println("All check boxes Are Unchecked......PASSSED");
			else
				System.out.println("All check boxes Are NOT Unchecked......FAILD");
				
		  }
		
	}

}
