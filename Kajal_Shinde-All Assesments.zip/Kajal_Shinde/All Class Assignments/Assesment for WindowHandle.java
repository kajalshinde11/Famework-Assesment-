package SeleniumScript.OKTraining;

import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowHandleAssesment {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://letskodeit.teachable.com/p/practice");
		D.manage().window().maximize();
		
		WebElement OpenTabButton =D.findElementById("opentab");
		OpenTabButton.click();
		
		String OriginalWindowHanldes=D.getWindowHandle();
		
		System.out.println(" Original Window" +D.getWindowHandle());//handle only original window 
		
		Set<String>Handles=D.getWindowHandles();
		
		for(String Handle:Handles)//Window Handle For Second Window 
		{
			D.switchTo().window(Handle);
			String Title=D.getTitle();
			
			if(Title.equals("Let's Kode It"))
			{
				break;
			}
		}
		WebElement LoginLink =D.findElementByPartialLinkText("Login");
		LoginLink.click(); 
		
		Thread.sleep(3000);
		D.close();
		Thread.sleep(3000);
		D.switchTo().window(OriginalWindowHanldes);
		System.out.println(D.getTitle());
		D.quit();
	}

}
