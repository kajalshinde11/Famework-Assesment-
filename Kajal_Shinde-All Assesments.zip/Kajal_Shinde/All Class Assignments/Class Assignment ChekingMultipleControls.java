package SeleniumScript.OKTraining;



import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChekingMultipleControls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 *Multiple checks 
		 *in single check we use the unique attribute and the Multiple we use the same values or attribute 
	
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		 
		ChromeDriver D =new ChromeDriver();
		D.get("https://letskodeit.teachable.com/p/practice");
		
		WebElement BenzCheck=D.findElementById("benzcheck");
		WebElement BmwCheck=D.findElementById("bmwcheck");
		WebElement HondaCheck=D.findElementById("Hondacheck");
		
		if(BenzCheck.isSelected()==false && BmwCheck.isSelected()==false && HondaCheck.isSelected()==false)
			System.out.println("All the checked.......PASSED");
		else
			System.out.println("All the checked.......FAILD");
			*/
			
		//Solution 1 :
		    System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		    ChromeDriver D =new ChromeDriver();
			D.get("https://letskodeit.teachable.com/p/practice");
			
			WebElement BnzCheck=D.findElementById("benzcheck");
			WebElement BmwCheck=D.findElementById("bmwcheck");
			WebElement HondaCheck=D.findElementById("hondacheck");
			
			if(BnzCheck.isSelected()==false && BmwCheck.isSelected()==false && HondaCheck.isSelected()==false)
				System.out.println("All the checked.......PASSED");
			else
				System.out.println("All the checked.......FAILD");
			
		//Solution 2 :
			/*List<WebElement>CheckBoxes=D.findElementsByName("cars");
		     D.findElementByCssSelector(null);
		     System.out.println(CheckBoxes.size());
		     */
			
			  List<WebElement>Checkboxes=D.findElementsByCssSelector("input[type='checkbox']");
			
			  System.out.println(Checkboxes.size());
		  
			  
			  //Solution 3 :

			  boolean FoundSelected=false;
			  int i=0;
			  while(i<Checkboxes.size())
			  {
				WebElement chek=Checkboxes.get(i);
				boolean IsCheckBoxSelected=chek.isSelected();
				if(IsCheckBoxSelected==true)
				
					FoundSelected=true;
					i++;
				
				if(FoundSelected==false)
					System.out.println("All check boxes Are Unchecked......PASSSED");
				else
					System.out.println("All check boxes Are NOT Unchecked......FAILD");
					
			  }
			  
	}

}
