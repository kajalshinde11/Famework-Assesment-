package SeleniumScript.OKTraining;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathClassAssignment2Orange {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		
		D.manage().window().maximize();
		D.get("https://opensource-demo.orangehrmlive.com/index.php/pim/ViewEmployeeList/reset/1");
		
		
         WebElement Column1 = D.findElementByXPath("//table/descendant::a[text()='blue']/parent::td/preceding-sibling::td/child::input");
		
		
		System.out.println(Column1.getText());
		
	}

}
