package Training.StringOperations;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.regex.Pattern;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class StringOperationTest {
	ConcatenateString Obj;
	String Result;
	
	@BeforeGroups("RegressionTest")
	public void InitGroup()
	{
		System.out.println("I am in Before Group");
		Obj=new ConcatenateString();
	}
	
	@BeforeClass
	public void Init()
	{
		System.out.println("I am in Before class");
		Obj=new ConcatenateString();
	}
	
	@BeforeMethod
	public void ReinitialiseResultVar()
	{
		System.out.println("I am in Before Method");
		Result=null;
	}
	@Test(priority=1,groups= {"RegressionTest"})
	public void TestConcatinateWithTwoString()
	{
		System.out.println("I am in 1st TestCase");
		Result=Obj.Concatenate("KAJAL","SHINDE");
		Assert.assertEquals(Result, "KAJAL SHINDE","Conacte string does not work with two Strings");
		
	}
	/*@Test
	public void containsNum() {
		System.out.println("I am in 2nd Test");
		Result=Obj.Concatenate("123", "456");
		Assert.assertEquals(Result,  "NOT A String Value");
	}*/
	
	
	@Test(dataProvider = "provideStrings")
	public void testConcatenationUsingDataDriven(String name, String surname, String result) {
		Result = Obj.Concatenate(name, surname);
		Assert.assertEquals(Result, result);
	}
	

	@DataProvider
	public Object[][] provideStrings() {
		Object[][] FullName = { 
				{ "KAJAL", "SHINDE", "KAJAL SHINDE" }, 
				{ "String", "Concatenate", "String Concatenate" },
				{ "Provide", "String", "Provide String" }
		};
		return FullName;
	}
	
	@Test(groups= {"SmokeTest"})
	public void concatenateOneStringOneEmptyString() {
	
		System.out.println("I am in 3rd test");
		Result = Obj.Concatenate("Kajal", " ");
		Assert.assertEquals(Result,"Kajal  ","Not a string value");
	}
	
	@Test(groups= {"RegressionTest"})
	public void concatenateOneStringOneNullString() {
		
		System.out.println("I am in 4th test");
		Result = Obj.Concatenate("KAJAL", null);
		Assert.assertEquals(Result,"KAJAL null","Not a string value");
	}
	
	
	
	@Test(groups= {"RegressionTest"})
	public void concatenateWithNumbers() {
		
		System.out.println("I am in 5th test");
		
		String Str1="Data";
		String Str2="Driven";
		
		Result = Obj.Concatenate(Str1, Str2);
		if((Str1.matches("[a-zA-Z]*$")) &&( Str2.matches("[a-zA-Z]*$"))) {
			
			Result=Obj.Concatenate(Str1, Str2);
		
			Assert.assertEquals(Result ,"Data Driven");
		}else
		{
			Assert.assertEquals(Result ,"Not a string value");
		}
		
	}
	
	
	@AfterMethod
	public void Aftermethod()
	{
		System.out.println("IN AFTER METHOD ");
		Result=" ";
	}

	@AfterClass
	public void TearDown()
	{
		System.out.println("I am in After Class");
		
	}
	
	//Simple copy 
	/*@BeforeSuite
	public void createResFolder()
	{
		System.out.println("I  am in Before Suite");
		try {
			Files.createDirectories(Paths.get("/.Execution1"));
		} catch (IOException e) {
			// TODO Auto-generated catch blo
			e.printStackTrace();
		}
	}
	
	@AfterSuite
	public void CopyResFolder()
	{
		System.out.println("I  am in After Suite");
		try {
			Files.copy(Paths.get(".\\target\\surefire-reports\\emailable-report.html"),Paths.get("./Execution1/Result.html"),StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	//with paramters Request ID
	
	
	
	@BeforeSuite
	@Parameters({"RequestID"})
	public void CreateResultFolder(String RequestID)
	{
		System.out.println("I am in Before Suite");
		try
		{
			Files.createDirectories(Paths.get("./"+RequestID));
			
		}
		catch (IOException e)
		{
			System.out.println("Problem in Creating a Result Directory");
			
		}
	}
	@Parameters({"RequestID"})
	@AfterSuite
	public void CopyResultFile(String ResultFolderName)
	{
		System.out.println("I am in After Suite");
		try
		{
			Files.copy(Paths.get("C:\\Users\\kajal\\eclipse-workspace\\StringOperations\\test-output"),Paths.get("./"+ResultFolderName+"/Result.html"), StandardCopyOption.REPLACE_EXISTING);
		}
		catch(IOException e) {
			System.out.println("Problem in copying Result file");
		}
	}
}


	


