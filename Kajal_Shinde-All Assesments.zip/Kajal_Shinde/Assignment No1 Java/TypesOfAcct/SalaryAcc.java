package TypesOfAccount;
import AccountSystem.Account;
import AccountSystemExceptions.InsufficientBalanceException;
public class SalaryAcc extends Account{
    public SalaryAcc(int accNo){
	super(accNo);
    }

    public void OpenAcct(){
	System.out.println("SALARY ACC OPENING PROCESS IS STARTED .......");
	System.out.println("ACCOUNT OPENING MAY TAKE 8 WORKING HOURS.");
    }
}