package TDDOpproch.ArithmeticOperations;

public class ArithmeticOperations {

	    //..........Function For Addition ........
		
		public int Addition(int No1, int No2) 
		{
			int Result = No1 + No2;
				return Result;
		}
		
		//..........Function For Subtraction.......
		public int Subtraction(int No1, int No2) 
		{
		int Result = No1 - No2;
			return Result;
		}

		//..........Function For Multiplication.....
		public int Multiplication(int No1, int No2) 
		{
		int Result = No1 * No2;
			return Result;
		}
		
		//...........Function For Division.........
		public int Division(int No1, int No2) 
		{
		int Result = No1 / No2;
			return Result;
		}
		
		//..........Function For Negative Numbers.....
		public int Negative(int No1,int No2)
		{
		int Result = No1 + No2;
		return Result;
		}
		
	}



