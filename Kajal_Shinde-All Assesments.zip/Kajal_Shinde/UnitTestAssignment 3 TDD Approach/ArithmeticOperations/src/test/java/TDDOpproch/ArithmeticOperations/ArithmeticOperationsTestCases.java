package TDDOpproch.ArithmeticOperations;
    import java.io.IOException;
	import java.nio.file.Files;
	import java.nio.file.Paths;
	import java.nio.file.StandardCopyOption;

	import org.testng.Assert;
	import org.testng.annotations.*;




	public class ArithmeticOperationsTestCases {
		
		
		ArithmeticOperations Math;
		int Result;
		
		
		//   Annotation Before Groups.
		
		
		@BeforeGroups("RegressionTest") //Regression Testing ......
		public void initGroups()
		{
			System.out.println("I am in Before Group 1");
			Math=new ArithmeticOperations();
		}
		
		
		@BeforeGroups("SmokeTest")    //Smoke Testing Done Here.....
		public void initBeforeSmoke() 
		{
			System.out.println("I am in Before Group 2");
			Math = new ArithmeticOperations();
		}
		
		
		//    Annotation  Before Class .
		
		
		@BeforeClass
		public void init() 
		{
			System.out.println("I am in Before Class");
			Math= new ArithmeticOperations();
		}
		
		
	   //     Annotations Before Method.
		
		
		@BeforeMethod
		public void ReintialisingResult()
		{
			Result=0;
		}
		
		///////////////////////////TEST CASES FOR ADDTIONS///////////////////////////
		
		//...............Test Case Addition Using Data Driven..... ...
		
		@Test( dataProvider="ProvideNumbers", groups= {"RegressionTest"})
		public void TestAddtion(int num1, int num2, int result) {

			Result =Math.Addition(num1,num2);
			Assert.assertEquals(Result, result, "Addition doesnt work with numbers");
		}
        /*
         TestCase 1: 100 + 20 = 120
         
         TestCase 2: 10 + (-2)= 8
         
         TestCase 3: 1000 + 2000 = 3000
         
         TestCase 4: 0 + 2 = 2
         
         TestCase 5: (-10) + 2 =-8
         
         TestCase 6: 0 + 0 = 0
         
         TestCase 7: (-10) + (-2) =12
         */
		
		@DataProvider
        public Object[][] ProvideNumbers() {
	          Object[][] SetOfValues = new Object[7][3];
	
              SetOfValues [0][0]=100;//Set Of Two Positive Numbers
			  SetOfValues [0][1]=20;
			  SetOfValues [0][2]=120;
				 
			  SetOfValues [1][0]=10;//Set Of One positive One Negative
		   	  SetOfValues [1][1]=-2;
			  SetOfValues [1][2]=8;
			  
			  SetOfValues [2][0]=1000;//Set Of One Bigger Numbers
		   	  SetOfValues [2][1]=2000;
			  SetOfValues [2][2]=3000;
			  
			  SetOfValues [3][0]=0;//Set Of One Smallest Numbers
		   	  SetOfValues [3][1]=2;
			  SetOfValues [3][2]=2;
			  
			  SetOfValues [4][0]=-10;//Set Of One Negative One Positive Numbers
		   	  SetOfValues [4][1]=2;
			  SetOfValues [4][2]=-8;
			  
			  SetOfValues [5][0]=0;//Set Of Addition With Zero Numbers
		   	  SetOfValues [5][1]=0;
			  SetOfValues [5][2]=0;
			  
			  SetOfValues [6][0]=-10;//Set Of One Negative One Positive Numbers
		   	  SetOfValues [6][1]=-2;
			  SetOfValues [6][2]=-12;
	 
	 
	 
	  return SetOfValues;
}
        
		
		
		////////////////////////  TEST CASES FOR SUBTRACTION  //////////////////////////////////
        
       //...Test Case 1: Subtraction Using Data Driven ...
    	
		  @Test( dataProvider="ProvideValues", groups= {"SmokeTest"})
		  public void TestSubtraction(int num1, int num2, int result) {

			Result = Math.Subtraction(num1,num2);
			Assert.assertEquals(Result, result, "Addition doesnt work with positive numbers");
		}
		  
		  /*
	         TestCase 1: 100 - 20 = 80
	         
	         TestCase 2: 10 - (-2)= 12
	         
	         TestCase 3: 2000 - 100 = 1900
	         
	         TestCase 4: 3 - 1 = 2
	         
	         TestCase 5: (-10) - 2 = -12
	         
	         TestCase 6: 0 - 0 = 0
	         
	         TestCase 7: (-10) - (-2) = 8
	         */

		@DataProvider
		public Object[][] ProvideValues() {
			Object[][] SetOfValues = new Object[7][3];
			
			 SetOfValues [0][0]=100;//Set Of Two Positive Numbers
			 SetOfValues [0][1]=20;
			 SetOfValues [0][2]=80;
			 
			 SetOfValues [1][0]=10;//Set Of One positive One Negative
			 SetOfValues [1][1]=-2;
			 SetOfValues [1][2]=12;
			 
			 SetOfValues [2][0]=2000;//Set Of One Bigger Numbers
		   	  SetOfValues [2][1]=100;
			  SetOfValues [2][2]=1900;
			  
			  SetOfValues [3][0]=3;//Set Of One Smallest Numbers
		   	  SetOfValues [3][1]=1;
			  SetOfValues [3][2]=2;
			  
			  SetOfValues [4][0]=-10;//Set Of One Negative One Positive Numbers
		   	  SetOfValues [4][1]=2;
			  SetOfValues [4][2]=-12;
			  
			  SetOfValues [5][0]=0;//Set Of Addition With Zero Numbers
		   	  SetOfValues [5][1]=0;
			  SetOfValues [5][2]=0;
			  
			  SetOfValues [6][0]=-10;//Set Of One Negative One Positive Numbers
		   	  SetOfValues [6][1]=-2;
			  SetOfValues [6][2]=-8;
			 
			 return SetOfValues;
		}
       
       
   	    ////////////////////  TEST CASES FOR MULTIPLICATION ////////////////////////

		
		//...Test Case 1: Multiplication of Two Positive Numbers...
		
		@Test(priority=1, dataProvider="ProvideIntegerValues")
		public void TestMultiplication(int num1, int num2, int result) {

			Result = Math.Multiplication(num1,num2);
			Assert.assertEquals(Result, result, "Addition doesnt work with positive numbers");
		}

		@DataProvider
		public Object[][] ProvideIntegerValues() {
			Object[][] SetOfValues = new Object[7][3];
			
			/*
	         TestCase 1: 10 * 20 = 200
	         
	         TestCase 2: 10 * (-2)= 20
	         
	         TestCase 3: 2000 * 10 = 20000
	         
	         TestCase 4: 3 * 1 = 3
	         
	         TestCase 5: (-10) * 2 = 20
	         
	         TestCase 6: 0 * 0 = 0
	         
	         TestCase 7: (-10) * (-2) = 20
	         */
			
			 SetOfValues [0][0]=10;//Set Of Two Positive Numbers
			 SetOfValues [0][1]=20;
			 SetOfValues [0][2]=200;
			 
			 SetOfValues [1][0]=10;//Set Of One positive One Negative
			 SetOfValues [1][1]=-2;
			 SetOfValues [1][2]=-20;
			 
			  SetOfValues [2][0]=2000;//Set Of One Bigger Numbers
		   	  SetOfValues [2][1]=10;
			  SetOfValues [2][2]=20000;
			  
			  SetOfValues [3][0]=3;//Set Of One Smallest Numbers
		   	  SetOfValues [3][1]=1;
			  SetOfValues [3][2]=3;
			  
			  SetOfValues [4][0]=-10;//Set Of One Negative One Positive Numbers
		   	  SetOfValues [4][1]=2;
			  SetOfValues [4][2]=-20;
			  
			  SetOfValues [5][0]=0;//Set Of Addition With Zero Numbers
		   	  SetOfValues [5][1]=0;
			  SetOfValues [5][2]=0;
			  
			  SetOfValues [6][0]=-10;//Set Of One Negative One Positive Numbers
		   	  SetOfValues [6][1]=-2;
			  SetOfValues [6][2]=20;
			 
			 
			 
			 
			 return SetOfValues;
		}
			////////////////////  TEST CASES FOR DIVISION  ///////////////////////////////
			
	    	
		//...Test Case Division  of  Numbers...
		
		@Test
		public void TestDivisionWithPositiveNumbers()
		{
			System.out.println("Test Case 1 Division Functionality");
			Result=Math.Division(100, 2);
			Assert.assertEquals(Result, 50,"Division is not work with the Positive numbers");
		}
		
		@Test
		public void TestDivisionWithNegativeNumbers()
		{
			
			System.out.println("Test Case  2 Division Functionality");
			Result=Math.Division(-100,- 2);
			Assert.assertEquals(Result,50,"Division is not work with the Positive numbers");
		}
			
			
			
			//        Annotation For After Method .
			
			@AfterMethod
			public void clearResult() {
				Result = 0;        //Calling After Method Set Result to Zero.
			}

			
		   //         Annotation For After Class .
			
			@AfterClass
			public void tearDown() {
				Math = null;      //Calling After Class Is Set The Object To Null 
			}
			
			
			
			//Before Suite ----
			
			
			
			@BeforeSuite
			@Parameters({"RequestID"})

			public void createResultFolder(String ResultDir) {
				System.out.println("I am in before Suite");
				try
				{
				Files.createDirectories(Paths.get("./"+ResultDir));
				}
				catch (IOException e)
				{
					System.out.println("Problem in creating a Result Directory");
				}
				
			}
			
			//After Suite ---

			@Parameters({"RequestID"})
			@AfterSuite

			public void copyResultFile(String RequestID) throws Exception{
				System.out.println("I am in after Suite");
				try {
					Files.copy(Paths.get("C:\\Users\\kajal\\eclipse-workspace\\ArithmeticOperations\\test-output\\emailable-report.html"), Paths.get("./"+RequestID+"/Result.html"),StandardCopyOption.REPLACE_EXISTING);	}
				catch (IOException e) {
					
						System.out.println("Problem in copying Result file");
				}
			}

	}


