package TrainingAssesment2.BankAccount;
    import java.io.IOException;
	import java.nio.file.Files;
	import java.nio.file.Paths;
	import java.nio.file.StandardCopyOption;

	import org.testng.Assert;
	import org.testng.annotations.AfterSuite;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.BeforeSuite;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Parameters;
	import org.testng.annotations.Test;

	public class BankSalaryAccountTest {
		SalaryAcct AccSal;
		double Result;
		
		@BeforeClass
		public void Init()
		{
			System.out.println("I am in Before Class");
			AccSal=new SalaryAcct(100);
		}
		
		@BeforeMethod
		public void ReinitialisedResult()
		{
			System.out.println("I am in Before Method");
			Result=0;
		}
		
		
		
		@Test(priority=1,dataProvider="provideDepositeAmount")
		public void testDepositeFunctionWithDataProvider(double amount,double expectedResult)
		{
			System.out.println("Using Data provider Deposite Money to Your Account");
			Result=AccSal.DepositeAmount(amount);
			Assert.assertEquals(Result, expectedResult,"Deposite function does not work with the Data provider Function");
		}
		
		@DataProvider
		public Object[][] provideDepositeAmount()
		{
			
			Object[][] setOfValues=new Object[2][2];
			
			setOfValues[0][0]=1000;
			setOfValues[0][1]=1000;
			
			setOfValues[1][0]=2000;
			setOfValues[1][1]=3000;
			
			return setOfValues;
		}
		
		
		@Test(priority=2,dataProvider="provideWithdrawAmount")
		public void testWithdrawFunctionWithDataProvider(double amount,double expectedResult)
		{
			System.out.println("Using Data provider for withdraw money");
			Result=AccSal.WithdrawAmount(amount);
			Assert.assertEquals(Result, expectedResult,"Withdraw function does not work with Data Provider");
		}

		@DataProvider
		public Object[][] provideWithdrawAmount()
		{
			
			Object[][] setOfValues=new Object[2][2];
			
			setOfValues[0][0]=1000;//withdraw amount
			setOfValues[0][1]=2000;//updated balance
			
			setOfValues[1][0]=500;
			setOfValues[1][1]=1500;
			
			return setOfValues;
		}
		
		@BeforeSuite
		@Parameters({"RequestID"})
		public void CreateResultFolder(String RequestID)
		{
			System.out.println("I am in Before Suite");
			try
			{
				Files.createDirectories(Paths.get("./"+RequestID));
				
			}
			catch (IOException e)
			{
				System.out.println("Problem in Creating a Result Directory");
				
			}
		}
		@Parameters({"RequestID"})
		@AfterSuite
		public void CopyResultFile(String ResultFolderName)
		{
			System.out.println("I am in After Suite");
			try
			{
				Files.copy(Paths.get("C:\\Users\\kajal\\eclipse-workspace\\StringOperations\\test-output"),Paths.get("./"+ResultFolderName+"/Result.html"), StandardCopyOption.REPLACE_EXISTING);
			}
			catch(IOException e) {
				System.out.println("Problem in copying Result file");
			}
		}
		}
		
		
	
	

