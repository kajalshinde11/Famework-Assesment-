package TrainingAssesment2.BankAccount;

public abstract class BankAccounts {
	
	private int AccountNo;
	protected double Bal;
	static final double RateOfInterest=10.00;	
	public BankAccounts(int ActNo)
	{
		AccountNo=ActNo;
	   Bal=0.0;	
	}

	public BankAccounts(int AccountNo,double Bal)
	{
		this.AccountNo=AccountNo;
		Bal=Bal;
	}
	
	public double DepositeAmount(double Amount)
	{
		Bal=Bal+Amount;
		return Bal;
	}
	public double GetBalance()
	{
		return Bal;
	}

	public void setBalance(double balance) {
	
		this.Bal=balance;
	}
	public double WithdrawAmount(double Amount)
	{
		if(Bal<Amount)
		{
			System.out.println("Balance is less than required balance so deposite some money");
			return 0;
		}
			else if(Bal>Amount)
			{
			Bal=Bal-Amount;
			System.out.println("Your Balance After Withdrawl is: "+ Bal);
			
			}
		
		return Bal;
		
	}
	public int Get_AccountNo()
	{
		return AccountNo;
	}

	public double EarnInterest()
	{
		double InterestEarned=(Bal*RateOfInterest)/100;
		Bal=Bal+RateOfInterest;
		
		return Bal;
		}

	public final void CloseAccount()
	{
	System.out.println("Closing Your Account");
	}

	public abstract void OpenAccount();

}


