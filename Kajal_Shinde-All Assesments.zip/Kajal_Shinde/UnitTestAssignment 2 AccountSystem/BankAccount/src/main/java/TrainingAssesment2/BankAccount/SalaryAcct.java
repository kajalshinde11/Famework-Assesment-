package TrainingAssesment2.BankAccount;

public class SalaryAcct  extends BankAccounts {

		public SalaryAcct(int AcctNo, double Bal) {
			super(AcctNo, Bal);
			
		}
		
		public SalaryAcct(int AcctNo) {
			super(AcctNo);
			
		}

		@Override
		public void OpenAccount() {
			// TODO Auto-generated method stub
			
		}


	}


