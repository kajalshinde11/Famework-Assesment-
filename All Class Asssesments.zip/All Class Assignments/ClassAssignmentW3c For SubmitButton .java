package SeleniumScript.OKTraining;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassAssignmentW3c {//checking control inside frame 

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_test");
		D.manage().window().maximize();
		D.switchTo().frame("iframeResult");  
		
		WebElement fName = D.findElementById("fname");
       	fName.sendKeys("kajal");
       	
       	String FirstNameEntered = fName.getAttribute("value");
       	
       	WebElement lName = D.findElementById("lname");
       	lName.sendKeys("shinde");
       	
       	String LastNameEntered = lName.getAttribute("value");
       	
       	WebElement SubmitButton = D.findElementByCssSelector("input[value='Submit']");
       	SubmitButton.click();
        Thread.sleep(5000);
        
       	WebElement DivElement =D.findElementByCssSelector("div[class='w3-container w3-large w3-border']");//thids Are css composite class name 
       	String DivText=DivElement.getText();
       	
       	if(DivText.contains(FirstNameEntered)&& DivText.contains(LastNameEntered))
       	{
       		System.out.println("Data got submitted sucessfully.....PASSED");
       	}
       	else
       	{
       		System.out.println("Data Not get submitted sucessfully.....FAILD");
       	}
       	
       	D.switchTo().defaultContent();
       	
       	WebElement RunButton =D.findElementByCssSelector("button[class='w3-button w3-bar-item w3-hover-white w3-hover-text-green']");
        RunButton.click();
       	
	}

}
