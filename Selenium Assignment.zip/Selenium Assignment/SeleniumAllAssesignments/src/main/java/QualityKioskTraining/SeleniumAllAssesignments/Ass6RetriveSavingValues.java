package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ass6RetriveSavingValues
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_table_test");
		D.manage().window().maximize();

		D.switchTo().frame("iframeResult");
		WebElement FebruarySavings = D.findElementByXPath("//table//td[text()='February']/following-sibling::td");
		
	
		System.out.print("SAVINGS OF MONTH February : ");
		System.out.print(FebruarySavings.getText());
	}

}
