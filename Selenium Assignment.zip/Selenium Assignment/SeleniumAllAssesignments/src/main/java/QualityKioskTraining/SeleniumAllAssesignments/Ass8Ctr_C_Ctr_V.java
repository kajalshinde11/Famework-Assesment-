package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Ass8Ctr_C_Ctr_V 
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_test");
		D.manage().window().maximize();
		
		D.switchTo().frame("iframeResult");
		WebElement firstNameText = D.findElementById("fname");
		WebElement lastNameText = D.findElementById("lname");
		
		String name = "Kajal";
		
	
		firstNameText.sendKeys(name);
		
		Actions actions = new Actions(D);
		actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
		
		
		actions.keyDown(Keys.CONTROL).sendKeys("c").keyUp(Keys.CONTROL).build().perform();

		actions.keyDown(lastNameText, Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).build().perform();
		
		
		String actualName = lastNameText.getAttribute("value");
		if(actualName.equals(name))
		{
			System.out.println("COPY PASTE OPERATION PERFROM CORRECTLY .........PASSED");
		}
		else 
		{
			System.out.println("COPY PASTE OPERATION PERFROM NOT CORRECTLY .........FAILD");
		}
		D.quit();
	}

	}


