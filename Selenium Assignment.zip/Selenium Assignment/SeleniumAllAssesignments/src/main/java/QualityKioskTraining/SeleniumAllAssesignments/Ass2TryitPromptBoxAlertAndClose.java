package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ass2TryitPromptBoxAlertAndClose {

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get(" https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		D.manage().window().maximize();
		
	    D.switchTo().frame("iframeResult");
					
	    WebElement TryitBtn1=D.findElementByXPath("//button[text()='Try it']");
		TryitBtn1.click();
						
		D.switchTo().alert().sendKeys(" Kajal Shinde ");
		Thread.sleep(5000);
		D.switchTo().alert().dismiss();
	}

}
