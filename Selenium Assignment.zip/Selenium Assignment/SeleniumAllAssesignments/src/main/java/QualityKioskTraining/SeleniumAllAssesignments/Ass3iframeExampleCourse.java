package QualityKioskTraining.SeleniumAllAssesignments;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ass3iframeExampleCourse
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kajal\\Desktop\\Java_Testing_Training\\Drivers\\ChromeDriver.exe");
		ChromeDriver D =new ChromeDriver();
		D.get("https://letskodeit.teachable.com/p/practice");
		D.manage().window().maximize();
		
		String courseName="Selenium";
		
		D.switchTo().frame("courses-iframe");
		WebElement course = D.findElementById("search-courses");
		course.sendKeys(courseName);
		

		String enteredCourseName = course.getAttribute("value");
		if(enteredCourseName.equals(courseName))
		{
			System.out.println(" ENTERED COURSE NAME IS CORRECT ....PASSED");
		}
		else
		{
			System.out.println(" ENTERED COURSE NAME IS NOT  CORRECT....FAILED");
		}
		D.quit();
	}

}
