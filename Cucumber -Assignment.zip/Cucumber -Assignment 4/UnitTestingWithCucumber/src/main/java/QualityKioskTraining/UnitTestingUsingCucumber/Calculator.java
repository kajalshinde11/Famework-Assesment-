package QualityKioskTraining.UnitTestingUsingCucumber;

public class Calculator {

	public int addition(int first,int second) {
		return first+second;
	}
	
	public int subtraction(int first,int second) {
		return first-second;
	}
	
	public int multiplication(int first,int second) {
		return first*second;
	}
	
	public int division(int first,int second) {
		return first/second;
	}
}
