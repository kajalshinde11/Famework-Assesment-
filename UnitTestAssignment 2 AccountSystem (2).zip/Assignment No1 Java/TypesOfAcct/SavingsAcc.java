package TypesOfAccount;
import AccountSystem.Account;
import AccountSystemExceptions.InsufficientBalanceException;
public class SavingsAccount extends Account{
    public SavingsAcc(int accNo, double bal){
	super(accNo,bal);
    }

    public void withdrawAmount(double amount) throws InsufficientBalanceException{
	if(amount > (balance-1000)){
	    throw new InsufficientBalanceException("Insufficient Balance"); 
	}
	balance -= amount;
    }

    public void OpenAcc(){
	System.out.println("Saving Account Opening Process Started .......");
	System.out.println("Account Opening may take 2 Working days.");
    }

}