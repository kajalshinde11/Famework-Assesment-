package AccountSystemDemo;
import AccountSystem.*;
import AccountSystemExceptions.*;
import TypesOfAccount.*;
class AccountSystemDemoMain{
    public static void main(String[] args){


	System.out.println("...RUNTIME POLYMORPHISUM...");
	Account Act = getAccountType(args[0]);
	acc.openAccount();
	System.out.println("Initial Balance of "+Act.getAccNo()+" is "+acc.getBalance());
	acc.depositAmount(4000.00);
	System.out.println("After 1st deposit  Balance of "+Act.getAccNo()+" is "+Act.getBalance());
	acc.earnInterest();
	System.out.println("After Earning Interest Balance of "+Act.getAccNo()+" is "+Act.getBalance());
	try{
	    acc.withdrawAmount(6000);
	    System.out.println("After Withdrawing Balance of "+Act.getAccNo()+" is "+Act.getBalance());
	}catch(InsufficientBalanceException e){
	    System.out.println(e.getMessage());
	}
	acc.closeAcc();
    }

    static Account getAccountType(String accountType){
	switch(accountType){
	    case "saving" : return new SavingsAccount(5,5000);
			    
	    case "salary" : return new SalaryAccount(5);
			    
	}
	return null;
    }

}