package AccountSystem;
import AccountSystemExceptions.InsufficientBalanceException;
public abstract class Account{

    private int accountNo;
    protected double balance;
    static final double interestRate = 0.10;

    public Account(int num){
	accountNo = num;
	balance = 0.0;
    }

    public Account(int num, double bal){
	accountNo = num;
	balance = bal;
    }

    public void withdrawAmount(double amount) throws InsufficientBalanceException{
	if(amount >= balance){
	    throw new InsufficientBalanceException("Insufficient Balance"); 
	}
	balance -= amount;
    } 

    public void depositAmount(double amount){
	balance += amount;
    }

    public void earnInterest(){
	balance += (balance * interestRate );
    }

    public double getBalance(){
	return balance;
    }

    public int getAccNo(){
	return accountNo;
    }

    // final method is not be overridden
    public final void closeAcc(){
	System.out.println("Closing an Account in may be 2 Working day");
    }

    public abstract void openAcc(); // Abstract Method

}